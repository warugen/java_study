package com.tj.homework;

public class CheckingAccount extends Account {
	private String cardNo;
	
	public CheckingAccount() {}

	public CheckingAccount(String accountNo, String ownerName, int balance, String cardNo) {
		super(accountNo, ownerName, balance);
		this.cardNo = cardNo;
	}
	
	public CheckingAccount(String accountNo, String ownerName, String cardNo) {
		super(accountNo, ownerName);
		this.cardNo = cardNo;
	}


	public int pay(String cardNo, int amount) {
		if(getCardNo().equals(cardNo)) {
			if (getBalance() < amount) {
				System.out.println(getOwnerName()+"�� �ܾ��� ���ڶ��ϴ�. ��� �Ұ��Դϴ�.");
				return 0;
			} else {
				setBalance(getBalance()-amount);
				System.out.println(getOwnerName()+"��, "+amount+"�� �����߽��ϴ�.(�ܿ� �ݾ� :" + getBalance()+"��)");
				return amount;
			}
			
		} else {
			System.out.println("ī���ȣ�� ��ġ���� �ʽ��ϴ�.");
			return 0;
		}
	}
	
	

	@Override
	public void printAccount() {
		super.printAccount();
		System.out.println("ī���ȣ : "+getCardNo());
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	
	
}
