package com.tj.homework;

public class CreditLineAccount extends CheckingAccount {
	private int creditLine;

	public CreditLineAccount() {}

	public CreditLineAccount(String accountNo, String ownerName, int balance, String cardNo, int creditLine) {
		super(accountNo, ownerName, balance, cardNo);
		this.creditLine = creditLine;
		
	}

	public CreditLineAccount(String accountNo, String ownerName, String cardNo, int creditLine) {
		super(accountNo, ownerName, cardNo);
		this.creditLine = creditLine;
	}
	
	public int pay(String cardNo, int amount) {
		if(getCardNo().equals(cardNo)) {
			if(creditLine < amount) {
				System.out.println(getOwnerName()+"�� ī���ѵ� "+creditLine+"�� �ʰ��Ͽ� ��� �Ұ��Դϴ�.");
				return 0;
			} else {
				creditLine -= amount;
				System.out.println(getOwnerName()+"��, "+amount+"�� �����߽��ϴ�.(�ܿ� �ѵ� :" +creditLine+"��)");
				return amount;
			}
		} else {
			System.out.println("ī���ȣ�� ��ġ���� �ʽ��ϴ�.");
			return 0;
		}
	}

	@Override
	public void printAccount() {
		super.printAccount();
		System.out.println("ī�� �ѵ��� : "+creditLine);
	}

	public int getCreditLine() {
		return creditLine;
	}

	public void setCreditLine(int creditLine) {
		this.creditLine = creditLine;
	}
	
	
}
