package com.tj.ex7_homework;

public class Customer {
	String name;		// �̸�
	String phone;		// ��ȭ��ȣ
	String birth;		// ����
	String address;		// �ּ�
	
	public Customer() {}
	public Customer(String name, String phone, String birth, String address) {
		this.name = name;
		this.phone = phone;
		this.birth = birth;
		this.address = address;
	}

	@Override
	public String toString() {
		return name + " " + phone + " " + birth + "�� " + address +"\r\n";
	}
	
	
}
