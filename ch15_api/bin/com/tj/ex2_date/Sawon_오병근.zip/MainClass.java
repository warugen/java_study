package com.tj.ex2_date;

public class MainClass {
	public static void main(String[] args) {
		Sawon1[] sa = { new Sawon1("d102-02", "ȫ�浿", Sawon1.COMPUER),
				new Sawon1("a201-01", "���¸�", Sawon1.ACCOUNTING),
				new Sawon1("b100-19", "�ֹν�", Sawon1.PLANNING, 2010, 3, 1),
				new Sawon1("c101-02", "������", Sawon1.HUMANRESOURCES),
				new Sawon1("d102-09", "Ȳ����", Sawon1.COMPUER, 1999, 1, 1)
				};
		
		for(Sawon1 s: sa) {
			System.out.println(s.infoString());
		}
		
	}
}
